ct=0
let ct=${1}-1
for i in `seq 0 ${ct}`
do
    echo $i
done
